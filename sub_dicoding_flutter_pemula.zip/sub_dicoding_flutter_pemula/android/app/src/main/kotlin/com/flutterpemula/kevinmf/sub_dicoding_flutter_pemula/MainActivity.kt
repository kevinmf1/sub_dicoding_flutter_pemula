package com.flutterpemula.kevinmf.sub_dicoding_flutter_pemula

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
